require "test_helper"

class CarCompareTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
